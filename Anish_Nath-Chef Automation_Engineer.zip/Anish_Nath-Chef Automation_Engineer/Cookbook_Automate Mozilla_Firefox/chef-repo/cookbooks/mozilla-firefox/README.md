# mozilla-firefox-cookbook

This cookbook installs a build of Firefox from Mozilla

## Supported Platforms

* Ubuntu

