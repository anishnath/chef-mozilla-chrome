user_pref("app.update.enabled", false);
user_pref("browser.places.importBookmarksHTML", false);
user_pref("browser.shell.checkDefaultBrowser", false); 
user_pref("browser.warnOnQuit", false);             
user_pref("browser.search.update", false);          
user_pref("extensions.update.enabled", false);
