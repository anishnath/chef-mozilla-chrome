#
# Cookbook Name:: mozilla-firefox
# Recipe:: default
#

version = node['mozilla-firefox']['version']
lang = node['mozilla-firefox']['language'] 

if node['mozilla-firefox']['64'] == true
  os = 'linux64'
else
  os = 'linux'
end

url = "https://download.mozilla.org/?product=firefox-#{version}-SSL&os=#{os}&lang=#{lang}"

ark 'firefox' do
  action :install
  url url
  version version
  extension "tar.bz2"
  has_binaries ['firefox']
end

node['mozilla-firefox']['dependencies'].each do |dep|
  package dep do
    action :install
  end
end

windows_batch "create_default_profile" do
    code <<-eoh font="">
    "#{node['mozilla-firefox']['program_files_directory']}/firefox" -createprofile default
    EOH
    action :nothing
    not_if { firefox_profile_exists? }
end

powershell "delete_old_profile" do
    code <<-eoh font="">
    $firefox_application_data_dir = "$ENV:USERPROFILE/Application Data/Mozilla/Firefox"
    Remove-Item -Recurse -Force $firefox_application_data_dir/Profiles
    Remove-Item $firefox_application_data_dir/profiles.ini
    EOH
    action :nothing
    only_if { firefox_profile_exists? }
end

cookbook_file "#{node['mozilla-firefox']['program_files_directory']}/defaults/profile/prefs.js" do
    source "prefs.js"
    notifies :run , "powershell[delete_old_profile]"
    notifies :run , "windows_batch[create_default_profile]"
end