Pre-requisties


The pref.js file will control the Firefox behaviour on what to allow



========== The pref.js present in the Reciepe

pref("app.update.enabled", false);
pref("browser.places.importBookmarksHTML", false);
pref("browser.shell.checkDefaultBrowser", false);
pref("browser.warnOnQuit", false);
pref("browser.search.update", false);
pref("extensions.update.enabled", false);

Th emaik cookbook name is mozilla-firefox