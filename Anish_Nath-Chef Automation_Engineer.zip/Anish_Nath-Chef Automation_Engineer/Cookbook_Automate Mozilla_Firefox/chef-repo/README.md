RUN THE Following command to Install Firefox
chef-solo -c solo.rb -j web.json