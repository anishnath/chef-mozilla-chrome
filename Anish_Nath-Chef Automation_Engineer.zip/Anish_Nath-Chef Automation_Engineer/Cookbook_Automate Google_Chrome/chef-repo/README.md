Steps to Install google-chrome using chef

=======RUN THE COMMAND ============= chef-solo -c solo.rb -j web.json