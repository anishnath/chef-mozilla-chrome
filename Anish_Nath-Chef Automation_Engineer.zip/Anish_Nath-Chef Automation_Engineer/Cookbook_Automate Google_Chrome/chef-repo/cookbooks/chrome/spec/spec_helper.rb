# Added by ChefSpec
require 'chefspec'
require 'chefspec/berkshelf'

ChefSpec::Coverage.start!
